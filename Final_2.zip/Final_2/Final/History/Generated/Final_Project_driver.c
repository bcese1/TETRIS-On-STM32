#include "Final_Project_objects.h"
#include "Final_Project_resources.h"
#include "built_in.h"


// TFT module connections
sbit TFT_BLED at GPIO_PORTA_DATA3_bit;
sbit TFT_CS at GPIO_PORTH_DATA6_bit;
char TFT_DataPort at GPIO_PORTJ_DATA;
sbit TFT_RD at GPIO_PORTC_DATA5_bit;
sbit TFT_RS at GPIO_PORTG_DATA7_bit;
sbit TFT_RST at GPIO_PORTH_DATA5_bit;
sbit TFT_WR at GPIO_PORTH_DATA4_bit;
sbit TFT_BLED_Direction at GPIO_PORTA_DIR3_bit;
sbit TFT_CS_Direction at GPIO_PORTH_DIR6_bit;
char TFT_DataPort_Direction at GPIO_PORTJ_DIR;
sbit TFT_RD_Direction at GPIO_PORTC_DIR5_bit;
sbit TFT_RS_Direction at GPIO_PORTG_DIR7_bit;
sbit TFT_RST_Direction at GPIO_PORTH_DIR5_bit;
sbit TFT_WR_Direction at GPIO_PORTH_DIR4_bit;
// End TFT module connections

// Touch Panel module connections
/*sbit DriveX_Left at GPIO_PORTB_DATA4_bit;
sbit DriveX_Right at GPIO_PORTE_DATA0_bit;
sbit DriveY_Up at GPIO_PORTE_DATA1_bit;
sbit DriveY_Down at GPIO_PORTB_DATA5_bit;
sbit DriveX_Left_Direction at GPIO_PORTB_DIR4_bit;
sbit DriveX_Right_Direction at GPIO_PORTE_DIR0_bit;
sbit DriveY_Up_Direction at GPIO_PORTE_DIR1_bit;
sbit DriveY_Down_Direction at GPIO_PORTB_DIR5_bit;*/
// End Touch Panel module connections

// Global variables
unsigned int Xcoord, Ycoord;
const ADC_THRESHOLD = 750;
char PenDown;
void *PressedObject;
int PressedObjectType;
unsigned int caption_length, caption_height;
unsigned int display_width, display_height;

int _object_count;
unsigned short object_pressed;
TBox *local_box;
TBox *exec_box;
int box_order;

static void InitializeTouchPanel() {
  TFT_Init_ILI9341_8bit(320, 240);

}


/////////////////////////
  TScreen*  CurrentScreen;

  TScreen                Screen1;
  TBox                   Box1;
  TBox                   * const code Screen1_Boxes[1]=
         {
         &Box1                 
         };



static void InitializeObjects() {
  Screen1.Color                     = 0x5AEB;
  Screen1.Width                     = 320;
  Screen1.Height                    = 240;
  Screen1.BoxesCount                = 1;
  Screen1.Boxes                     = Screen1_Boxes;
  Screen1.ObjectsCount              = 1;


  Box1.OwnerScreen     = &Screen1;
  Box1.Order           = 0;
  Box1.Left            = 87;
  Box1.Top             = 48;
  Box1.Width           = 133;
  Box1.Height          = 115;
  Box1.Pen_Width       = 1;
  Box1.Pen_Color       = 0xFFFF;
  Box1.Visible         = 1;
  Box1.Active          = 1;
  Box1.Transparent     = 1;
  Box1.Gradient        = 1;
  Box1.Gradient_Orientation = 0;
  Box1.Gradient_Start_Color = 0xFFFF;
  Box1.Gradient_End_Color = 0xC618;
  Box1.Color           = 0xC618;
  Box1.PressColEnabled = 1;
  Box1.Press_Color     = 0xE71C;
}

static char IsInsideObject (unsigned int X, unsigned int Y, unsigned int Left, unsigned int Top, unsigned int Width, unsigned int Height) { // static
  if ( (Left<= X) && (Left+ Width - 1 >= X) &&
       (Top <= Y)  && (Top + Height - 1 >= Y) )
    return 1;
  else
    return 0;
}


#define GetBox(index)                 CurrentScreen->Boxes[index]


void DrawBox(TBox *ABox) {
  if (ABox->Visible != 0) {
    if (object_pressed == 1) {
      object_pressed = 0;
      TFT_Set_Brush(ABox->Transparent, ABox->Press_Color, ABox->Gradient, ABox->Gradient_Orientation, ABox->Gradient_End_Color, ABox->Gradient_Start_Color);
    }
    else {
      TFT_Set_Brush(ABox->Transparent, ABox->Color, ABox->Gradient, ABox->Gradient_Orientation, ABox->Gradient_Start_Color, ABox->Gradient_End_Color);
    }
    TFT_Set_Pen(ABox->Pen_Color, ABox->Pen_Width);
    TFT_Rectangle(ABox->Left, ABox->Top, ABox->Left + ABox->Width - 1, ABox->Top + ABox->Height - 1);
  }
}

void DrawScreen(TScreen *aScreen) {
 unsigned int order;
  unsigned short box_idx;
  TBox *local_box;
  char save_bled, save_bled_direction;

  object_pressed = 0;
  order = 0;
  box_idx = 0;
  CurrentScreen = aScreen;

  if ((display_width != CurrentScreen->Width) || (display_height != CurrentScreen->Height)) {
    save_bled = TFT_BLED;
    save_bled_direction = TFT_BLED_Direction;
    TFT_BLED_Direction = 1;
    TFT_BLED           = 0;
    TFT_Init_ILI9341_8bit(CurrentScreen->Width, CurrentScreen->Height);
    TFT_Fill_Screen(CurrentScreen->Color);
    display_width = CurrentScreen->Width;
    display_height = CurrentScreen->Height;
    TFT_BLED           = save_bled;
    TFT_BLED_Direction = save_bled_direction;
  }
  else
    TFT_Fill_Screen(CurrentScreen->Color);


  while (order < CurrentScreen->ObjectsCount) {
    if (box_idx < CurrentScreen->BoxesCount) {
      local_box = GetBox(box_idx);
      if (order == local_box->Order) {
        box_idx++;
        order++;
        DrawBox(local_box);
      }
    }

  }
}

void Init_MCU() {
  GPIO_Config(&GPIO_PORTA_DATA_BITS, 0b00001000, _GPIO_DIR_OUTPUT, _GPIO_CFG_DIGITAL_ENABLE | _GPIO_CFG_DRIVE_8mA, 0);
  TFT_BLED = 1;
  TFT_Set_Default_Mode();
  TP_TFT_Set_Default_Mode();
}

void Start_TP() {
  Init_MCU();

  //InitializeTouchPanel();
  InitializeObjects();
  display_width = Screen1.Width;
  display_height = Screen1.Height;
  DrawScreen(&Screen1);
}