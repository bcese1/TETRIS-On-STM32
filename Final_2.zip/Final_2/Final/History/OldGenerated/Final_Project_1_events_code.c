#include "Final_Project_1_objects.h"
#include "Final_Project_1_resources.h"

//--------------------- User code ---------------------//

//----------------- End of User code ------------------//

// Event Handlers
void Button1OnPress() 
{
     GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_13);
     GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_12);
     if(GPIOC_IDR.B13 == 0)
     {
       DrawScreen(&Screen2);
       GPIOD_ODR.B12 = 1;
     }
}
