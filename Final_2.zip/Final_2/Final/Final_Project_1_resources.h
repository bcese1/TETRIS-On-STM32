/*
Header for the Resource file to load in images to use on the display 
*/

const code char Terminal10x18_Regular[];
const code char Terminal6x8_Regular[];
const code char bg_bmp[38438];
const code char bg2_bmp[38438];