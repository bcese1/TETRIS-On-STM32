/*
The main file in the project
This will start the game and call the objects header to load the game screen 
 */

#include "Final_Project_1_objects.h"

void Button1OnPress();
extern start_game;
extern oneSecFlag;
extern TIM3_counter;
extern pause;
volatile int spawn_axis = 0;
void main() {

  Start_TP();
  ExternalIntConfiguration();
  Timer3Configuration();
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_13);
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_2);
  GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_5);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_6);



  //srand(TIM3_counter);

  while (1) {
  {
     if(start_game == 1 && oneSecFlag == 1)
     {
      //spawn_shape();
      if(pause == 0)
      {
      move_shape_down();
      }
      //move_shape_right();
      }
    //Check_TP();
    //Button1OnPress();
    /*if (y0 + (2*boxSize) < 216 )
    {
     move_shape();
    }*/
    
     //spawn_axis = rand()%4;
    

  }
}
}